import javax.swing.*;

import java.awt.event.*;
import java.awt.*;
import java.util.*;

import javax.swing.JFrame.*;
import javax.swing.JPanel.*;
import javax.swing.JButton.*;
import javax.swing.JLabel.*;
import javax.swing.JPanel.*;
import javax.swing.JRadioButton.*;
import javax.swing.JTextField.*;
import javax.swing.JOptionPane;
import javax.swing.JComboBox.*;

import java.sql.*;
public class AdminPanel implements ActionListener
{
public JFrame jf4;
public JPanel panel4,panel5,panel7,panel8;
public String a1,a2,a3,a4,a5,a6,a7,a8,a9,a10;
public Statement stmt; 
public JLabel q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,qa1,qa2,qa3,qa4,qa5,qa6,qa7,qa8,qa9,qa10;
public static JButton report,newuser,cot,delete;
public String password1,password2,user1,user2;
public JLabel username,password;
public static  JButton logout;
public JTextField t1;
public JTextField t2;
public ResultSet rs;

public AdminPanel()
{
		jf4=new JFrame("Report Form");	

		panel4=new JPanel();
		
		jf4.add(panel4);
		panel4.setBackground(new Color(0.9f,0.3f,0.5f));
		panel4.setLayout(null);
	
		
		
		ImageIcon i1=new ImageIcon("C:\\Users\\Nilu\\workspace\\FeedbackMS\\images\\admin.png");
		JLabel jl1=new JLabel(i1);
		jl1.setBounds(10,550,450,60);
		panel4.add(jl1);

	ImageIcon i2=new ImageIcon("C:\\Users\\Nilu\\workspace\\FeedbackMS\\images\\mmcoe.jpg");
		
		JLabel jl2=new JLabel(i2);
		jl2.setBounds(250,70,700,400);
		panel4.add(jl2);

	
		
		GraphicsDevice gd=GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
		int x=gd.getDisplayMode().getWidth();
		int y=gd.getDisplayMode().getHeight();

		jf4.setSize(x,y);

		jf4.show();

		newuser=new JButton("Add New User");
		newuser.setBounds(30,90,150,30);
		panel4.add(newuser);
		delete=new JButton("Delete User");
		delete.setBounds(30,170,150,30);
		panel4.add(delete);
		report=new JButton("Report");
		report.setBounds(30,250,150,30);
		panel4.add(report);
		
		cot=new JButton("Comments");
		cot.setBounds(30,330,150,30);
		panel4.add(cot);

		logout=new JButton("Logout");
		logout.setBounds(30,410,150,30);
		panel4.add(logout);

		newuser.addActionListener(this);
		delete.addActionListener(this);
		report.addActionListener(this);
		cot.addActionListener(this);
		logout.addActionListener(this);
		
}
public void actionPerformed(ActionEvent aaa)
{
		String s=aaa.getActionCommand();
		if(s=="Report")
		{
			allreport();
			
		}
		else if(s=="Add New User")
		{
			new NewUserForm();

		}
		else if(s=="Comments")
		{
			comment();
		}
		else if(s=="Delete User")
		{
			new DeleteUserForm();
		}
		else if(s=="Logout")
		{
			jf4.hide();
			
			
		}
		
}public void allreport()
{
	
		panel5=new JPanel();

		jf4.add(panel5);
		panel5.setBounds(250,70,750,450);
		panel5.setBackground(new Color(255,153,255));
		panel5.setLayout(null);
		try
		{	
	
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/feedbackdb","root","aryan99");
		
			Statement stmt = con.createStatement();
			int k=1,l=1,m=1,k1=0,l1=0,m1=0,k2=0,l2=0,m2=0,k3=0,l3=0,m3=0,n3=0,k4=0,l4=0,m4=0;
			int	 k5=0,l5=0,m5=0,k6=0,l6=0,m6=0,k7=0,l7=0,m7=0,k8=0,l8=0,m8=0,k9=0,l9=0,m9=0,k10=0,l10=0,m10=0;
			String sql = "select * from tblFeedback";
			rs=stmt.executeQuery(sql);
		
	while(rs.next())
	{
		a1=(rs.getString("fascilty"));
		a2=(rs.getString("environment"));
		a3=(rs.getString("teaching"));
		a4=(rs.getString("curricular"));
		a5=(rs.getString("cleaning"));
		a6=(rs.getString("water"));
		a7=(rs.getString("complaints"));
		a8=(rs.getString("wifi"));
		a9=(rs.getString("lab"));
		a10=(rs.getString("placement"));
		
			if(a1.equals("Good"))
			{
				k=k+1;
			
			}
			else if(a1.equals("Average"))
			{
				l=l+1;
						    	
			}
			else if(a1.equals("Bad"))
			{
	
				m=m+1;

			}
			else if(a1.equals(null))
			{
				rs.next();
			}/////////2

			if(a2.equals("Good"))
			{
				k1=k1+1;
			
			}
			else if(a2.equals("Average"))
			{
				l1=l1+1;
							    	
			}
			else if(a2.equals("Bad"))
			{
				m1=m1+1;
			}
			else if(a2.equals(null))
			{
				rs.next();
			}
			
		//////////3
		if(a3.equals("Good"))
			{
				k2=k2+1;
			}
			else if(a3.equals("Average"))
			{
				l2=l2+1;
							    	
			}
			else if(a3.equals("Bad"))
			{
				m2=m2+1;
			}
			else if(a3.equals(null))
			{
				rs.next();
			}
/////////4
			if(a4.equals("Good"))
			{
				k3=k3+1;
			}
			else if(a4.equals("Average"))
			{
				l3=l3+1;
							    	
			}
			else if(a4.equals("Bad"))
			{
				m3=m3+1;
			}
			else if(a4.equals(null))
			{
				rs.next();
			}
			///////////5
			if(a5.equals("Good"))
			{
				k4=k4+1;
			}
			else if(a5.equals("Average"))
			{
				l4=l4+1;
							    	
			}
			else if(a5.equals("Bad"))
			{
				m4=m4+1;
			}
			else if(a5.equals(null))
			{
				rs.next();
			}
		////////6
		if(a6.equals("Good"))
			{
				k5=k5+1;
				
			}
			else if(a6.equals("Average"))
			{
				l5=l5+1;
							    	
			}
			else if(a6.equals("Bad"))
			{
				m5=m5+1;
			}
			else if(a6.equals(null))
			{
				rs.next();
			}
			////////7
			if(a7.equals("Good"))
			{
				k6=k6+1;
				
			}
			else if(a7.equals("Average"))
			{
				l6=l6+1;
							    	
			}
			else if(a7.equals("Bad"))
			{
				m6=m6+1;
			}
			else if(a7.equals(null))
			{
				rs.next();
			}
			////////8
			if(a8.equals("Good"))
			{
				k7=k7+1;
			//	System.out.println(k);
			}
			else if(a8.equals("Average"))
			{
				l7=l7+1;
							    	
			}
			else if(a8.equals("Bad"))
			{
				m7=m7+1;
			}
			else if(a8.equals(null))
			{
				rs.next();
			}
			/////////9
			if(a9.equals("Good"))
			{
				k8=k8+1;
						}
			else if(a9.equals("Average"))
			{
				l8=l8+1;
							    	
			}
			else if(a9.equals("Bad"))
			{
				m8=m8+1;
			}
			else if(a9.equals(null))
			{
				rs.next();
			}
			/////////10
			if(a10.equals("Good"))
			{
				k9=k9+1;
			//	System.out.println(k);
			}
			else if(a10.equals("Average"))
			{
				l9=l9+1;
							    	
			}
			else if(a10.equals("Bad"))
			{
				m9=m9+1;
			}
			else if(a10.equals(null))
			{
				rs.next();
			}


	}

	
	
		if(k>=l && k>=m)
			{
				System.out.println("Q1: Goooooood");
					qa1 =new JLabel("Good");
					qa1.setBounds(570,150,40,40);
					panel5.add(qa1);
	
			}
			else if(l>=k && l>=m)
			{
				System.out.println("Avg");
					qa1 =new JLabel("Average");
					qa1.setBounds(570,150,70,40);
					panel5.add(qa1);

			}
			else if(m>=k && m>=l)
			{
				System.out.println("Q1: Bad");
					qa1 =new JLabel("Bad");
					qa1.setBounds(570,150,40,40);
					panel5.add(qa1);

			}//////2
			if(k1>=l1 && k1>=m1)
			{
				System.out.println("Q2: Goooooood");
					qa2 =new JLabel("Good");
					qa2.setBounds(570,180,40,40);
					panel5.add(qa2);
	
			}
			else if(l1>=k1 && l1>=m1)
			{
				System.out.println("Q2: Avvgggggg");
					qa2 =new JLabel("Average");
					qa2.setBounds(570,180,70,40);
					panel5.add(qa2);
			}
			else if(m1>=k1 && m1>=l1)
			{
				System.out.println("Q2: Baddddd");
					qa2 =new JLabel("Bad");
					qa2.setBounds(570,180,40,40);
					panel5.add(qa2);
			}
	////////3
			if(k2>=l2 && k2>=m2)
			{
				System.out.println("Q3: Goooooood");
					qa3 =new JLabel("Good");
					qa3.setBounds(570,210,40,40);
					panel5.add(qa3);

			}
			else if(l2>=k2 && l2>=m2)
			{
				System.out.println("Q3: Avvgggggg");
					qa3 =new JLabel("Average");
					qa3.setBounds(570,210,70,40);
					panel5.add(qa3);

			}
			else if(m2>=k2 && m2>=l2)
			{
				System.out.println("Q3: Baddddd");
					qa3 =new JLabel("Bad");
					qa3.setBounds(570,210,40,40);
					panel5.add(qa3);

			}
	//////4
			if(k3>=l3 && k3>=m3)
			{
				System.out.println("Q4: Goooooood");
					qa4 =new JLabel("Good");
					qa4.setBounds(570,240,40,40);
					panel5.add(qa4);

			}
			else if(l3>=k3 && l3>=m3)
			{
				System.out.println("Q4: Avvgggggg");
					qa4 =new JLabel("Average");
					qa4.setBounds(570,240,70,40);
					panel5.add(qa4);

			}
			else if(m3>=k3 && m>=l)
			{
				System.out.println("Q4: Baddddd");
					qa4 =new JLabel("Bad");
					qa4.setBounds(570,240,40,40);
					panel5.add(qa4);
			}
//////////5
			if(k4>=l4 && k4>=m4)
			{
				System.out.println("Q5: Goooooood");
					qa5 =new JLabel("Good");
					qa5.setBounds(570,270,40,40);
					panel5.add(qa5);

			}
			else if(l4>=k4 && l4>=m4)
			{
				System.out.println("Q5: Avvgggggg");
					qa5 =new JLabel("Average");
					qa5.setBounds(570,270,70,40);
					panel5.add(qa5);
			}
			else if(m4>=k4 && m4>=l4)
			{
				System.out.println("Q5: Baddddd");
					qa5 =new JLabel("Bad");
					qa5.setBounds(570,270,40,40);
					panel5.add(qa5);
			}
//////////6
			if(k5>=l5 && k5>=m5)
			{
				System.out.println("Q6: Goooooood");
					qa6 =new JLabel("Good");
					qa6.setBounds(570,300,40,40);
					panel5.add(qa6);

			}
			else if(l5>=k5 && l5>=m5)
			{
				System.out.println("Q6: Avvgggggg");
					qa6 =new JLabel("Average");
					qa6.setBounds(570,300,70,40);
					panel5.add(qa6);
			}
			else if(m5>=k5 && m5>=l5)
			{
				System.out.println("Q6: Baddddd");
					qa6 =new JLabel("Bad");
					qa6.setBounds(570,300,40,40);
					panel5.add(qa6);
			}
///////////7
			if(k6>=l6 && k6>=m6)
			{
				System.out.println("Q7: Goooooood");
				qa7 =new JLabel("Good");
					qa7.setBounds(570,330,40,40);
					panel5.add(qa7);

			}
			else if(l6>=k6 && l6>=m6)
			{
				System.out.println("Q7: Avvgggggg");
					qa7 =new JLabel("Average");
					qa7.setBounds(570,330,70,40);
					panel5.add(qa7);
			}
			else if(m6>=k6 && m6>=l6)
			{
				System.out.println("Q7: Baddddd");
					qa7 =new JLabel("Bad");
					qa7.setBounds(570,330,40,40);
					panel5.add(qa7);
			}
////////////8
			if(k7>=l7 && k7>=m7)
			{
				System.out.println("Q8: Goooooood");
				qa8 =new JLabel("Good");
					qa8.setBounds(570,360,70,40);
					panel5.add(qa8);
			}
			else if(l7>=k7 && l7>=m7)
			{
				System.out.println("Q8: Avvgggggg");
				qa8 =new JLabel("Average");
					qa8.setBounds(570,360,70,40);
					panel5.add(qa8);
			}
			else if(m7>=k7 && m7>=l7)
			{
				System.out.println("Q8: Baddddd");
					qa8 =new JLabel("Bad");
					qa8.setBounds(570,360,40,40);
					panel5.add(qa8);
			}
///////////9
			if(k8>=l8 && k8>=m8)
			{
				System.out.println("Q9: Goooooood");
				qa9 =new JLabel("Good");
					qa9.setBounds(570,390,40,40);
					panel5.add(qa9);

			}
			else if(l8>=k8 && l8>=m8)
			{
				System.out.println("Q9: Avvgggggg");
				qa9 =new JLabel("Average");
					qa9.setBounds(570,390,70,40);
					panel5.add(qa9);
			}
			else if(m8>=k8 && m8>=l8)
			{
				System.out.println("Q9: Baddddd");
				qa9 =new JLabel("Bad");
					qa9.setBounds(570,390,40,40);
					panel5.add(qa9);
			}

////////10
			if(k9>=l9 && k9>=m9)
			{
				System.out.println("Q10: Goooooood");
					qa10 =new JLabel("Good");
					qa10.setBounds(570,420,40,40);
					panel5.add(qa10);
			}
			else if(l9>=k9 && l9>=m9)
			{
				System.out.println("Q10: Avvgggggg");
					qa10 =new JLabel("Average");
					qa10.setBounds(570,420,70,40);
					panel5.add(qa10);
			}
			else if(m9>=k9 && m9>=l9)
			{
				System.out.println("Q10: Baddddd");
					qa10 =new JLabel("Bad");
					qa10.setBounds(570,420,40,40);
					panel5.add(qa10);
			}


			
		JLabel title =new JLabel("REPORT");
		title.setBounds(300,40,450,30);
		title.setFont(new Font("Times New Roman", Font.BOLD, 38));
		panel5.add(title);

		JLabel que =new JLabel("Questions");
		que.setBounds(30,120,110,20);
		que.setFont(new Font("Dialog", Font.BOLD, 18));
		panel5.add(que);

		JLabel ans =new JLabel("Answer");
		ans.setBounds(550,120,100,20);
		ans.setFont(new Font("Dialog", Font.BOLD, 18));
		panel5.add(ans);

		q1=new JLabel("Q1:  Overall how satisfied are you with facilities provided in Institution ? ");
		q1.setBounds(30,140,450,40);
		panel5.add(q1);

	
		q2=new JLabel("Q2:  Overall how satisfied are you with the Environment in College Campus ?");
		q2.setBounds(30,170,450,40);
		panel5.add(q2);

		q3=new JLabel("Q3:  How satisfied are you with teaching process ?");
		q3.setBounds(30,200,450,40);
		panel5.add(q3);
	
		q4=new JLabel("Q4: How satisfied are you with Curricular and Extra Curricular activities ?");
		q4.setBounds(30,230,450,40);
		panel5.add(q4);
		
		q5=new JLabel("Q5: How satisfied are you with Canteen in the campus ?");
		q5.setBounds(30,260,450,40);
		panel5.add(q5);
		
		q6=new JLabel("Q6: How satisfied are you with Drinking water Facilities ?");
		q6.setBounds(30,290,450,40);
		panel5.add(q6);
		
		q7=new JLabel("Q7: How satisfied are you with resolving the complaints ?");
		q7.setBounds(30,320,450,40);
		panel5.add(q7);
		
		q8=new JLabel("Q8: You are satisfied with connection spped ? ");
		q8.setBounds(30,350,450,40);
		panel5.add(q8);
		
		q9=new JLabel("Q9: You are satisfied with software available in lab ?");
		q9.setBounds(30,380,450,40);
		panel5.add(q9);
		
		q10=new JLabel("Q10: How satisfied are you with Placement provided by us ?");
		q10.setBounds(30,410,450,40);
		panel5.add(q10);

	
	}	
	catch(Exception oa)
	{
		System.out.println("\n\t Error Here... "+oa);
	}
		
}
public void comment()
{
	try
	{
		
		panel7=new JPanel();

		jf4.add(panel7);
		//panel7.setBounds(250,20,750,650);
		panel7.setBounds(250,70,750,450);
		panel7.setBackground(new Color(255,153,255));
		panel7.setLayout(null);
		panel7.show();
	
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/feedbackdb","root","aryan99");
			stmt = con.createStatement();
			
		JLabel ti =new JLabel("Comments and Suggestions");
		ti.setBounds(250,40,700,30);
		ti.setFont(new Font("Dialog",Font.BOLD,20));
		panel7.add(ti);

			
		    String sql = "select * from tblFeedback";
			rs=stmt.executeQuery(sql);
			 String co,s;	
			 JLabel c; 
			 int x=70,y=150,a,b;
			 int i=1;
		    while(rs.next())
		    {
				 
				  co=(rs.getString("suggestion"));
				  
				  c=new JLabel(i+")"+co);
				 
				  c.setBounds(x,y,600,20);
				  panel7.add(c);
				  i=i+1;
				  y=y+50;
				  
			}
			    stmt.close();
				con.close();
		 }
		 catch(Exception exe)
		 {
			System.out.println(exe+" .........while fetching suggestion and comments.....");
				
		 }
}

	
	public static void main(String args[])
	{

		new AdminPanel();
	}

}