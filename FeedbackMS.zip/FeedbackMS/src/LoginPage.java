import javax.swing.*;

import java.awt.event.*;
import java.awt.*;
import java.util.*;

import javax.swing.JFrame.*;
import javax.swing.JPanel.*;
import javax.swing.JButton.*;
import javax.swing.JLabel.*;
import javax.swing.JPanel.*;
import javax.swing.JRadioButton.*;
import javax.swing.JTextField.*;
import javax.swing.JOptionPane;
import javax.swing.JComboBox.*;

import java.awt.Toolkit.*;
import java.sql.*;

public class LoginPage implements ActionListener
{
public String user1,password1,user2,password2,ba,bb;
public JLabel username,password;
public static JTextField usertextfield;
public static JPasswordField passwordfield;
public static JButton login,newuser;
public JFrame jf;
public JPanel panel;
public Statement st; 
public  ResultSet rs;
public Dimension screenSize;
public Toolkit zz;
public Double width,height;
public int x,y;

public LoginPage()
{
		
		jf=new JFrame("Registration Form");
		panel=new JPanel();

		jf.add(panel);
		panel.setBackground(new Color(102,178,255));
		panel.setLayout(null);
		
		
		ImageIcon i2=new ImageIcon("C:\\Users\\Nilu\\workspace\\FMS\\images\\mmcoe1.png");
		JLabel jl2=new JLabel();

		jl2.setBounds(50,150,500,500);
		jl2.setIcon(i2);
		panel.add(jl2);

		
		JLabel tit=new JLabel("Feedback Management System");
		tit.setFont(new Font("Dialog", Font.BOLD, 40));
		tit.setBounds(200,100,700,50);
		panel.add(tit);
		
		username=new JLabel("Username");
		username.setBounds(582,304,100,40);
		panel.add(username);
		
		 password=new JLabel("Password");
		password.setBounds(582,344,100,40);
		panel.add(password);
		
		
		usertextfield=new JTextField();
		usertextfield.setBounds(682,304,120,30);
		panel.add(usertextfield);
		
		passwordfield=new JPasswordField();
		
		passwordfield.setBounds(682,344,120,30);
		panel.add(passwordfield);
		
		login=new JButton("Login");
		login.setBounds(630,400,90,30);
		panel.add(login);
		
		
		
		login.addActionListener(this);
		
		GraphicsDevice gd=GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
		int x=gd.getDisplayMode().getWidth();
		int y=gd.getDisplayMode().getHeight();
		
		jf.setSize(x,y);

		jf.show();
		
	}
	
	public static void main(String args[])
	{	
		new LoginPage();
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String s=ae.getActionCommand();
		if(s=="Login")
		{
			try
			{		
				
				user1= usertextfield.getText();
				System.out.println("\n\t username entereed.."+user1);
				password1= new String(passwordfield.getText());
				ba=user1;

				int flag = 1,f;
				if((user1.isEmpty()) && (password1.isEmpty()))
				{
					System.out.println("Blank String is Not permitted...");
					flag=0;
					JOptionPane.showMessageDialog(null,"Blank String is Not permitted...");
				}
				else if((user1.isEmpty()) && (password1.length()!=0))
				{
					flag=0;
					System.out.println("Username is Required..");
					JOptionPane.showMessageDialog(null,"Username is Required..");
				}
				else if((user1.length()!=0) && (password1.isEmpty()))
				{
					flag=0;
					System.out.println("Password is Required...");
					JOptionPane.showMessageDialog(null,"Password is Required...");
				}
				else if((user1.equalsIgnoreCase("admin")) && (password1.equalsIgnoreCase("admin123")))
				{
					   jf.hide();
					      new AdminPanel();
					   flag=0;
					   JOptionPane.showMessageDialog(null,"Admin Login Successful...");
					
			 	}
				else if(flag==1)
				{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/feedbackdb","root","aryan99");
					st = con.createStatement();
					
					String sql = "select * from tblStudInfo";
					rs=st.executeQuery(sql);
			 	 
					while(rs.next())
					{
						user2=(rs.getString("firstname"));
					//	   JOptionPane.showMessageDialog(null,"Data in database..."+ user2);
						password2=(rs.getString("password"));
				        if((user1.equalsIgnoreCase(user2)) && (password1.equalsIgnoreCase(password2)))
				        {
				        	jf.hide();
				            	new FeedbackForm(usertextfield.getText());
				            	JOptionPane.showMessageDialog(null,"User login Successful...");
				            	flag=0;
				            	break;
						}
				        
				  }					  
				  if(flag!=0)
				  {
					   JOptionPane.showMessageDialog(null,"Wrong Username or Password");
				  }					
		          //st.close();
				  //con.close();
				}
		 }
		 catch(Exception e)
		 {
			System.out.println(e);
				
		 }
		}
	
			
	}
}