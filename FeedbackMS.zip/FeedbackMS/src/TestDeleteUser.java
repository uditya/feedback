import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestDeleteUser extends TestCase {
	DeleteUserForm window;
	@Before
	@Override
	protected void setUp() throws Exception {
		window=new DeleteUserForm();
		window.deleteframe.setVisible(true);
		super.setUp();
		System.out.println("\n\t Window Created...");
	}

	@Test
	public void testIsShowing() throws InterruptedException
	{
		assertTrue(window.deleteframe.isShowing());
		System.out.println("\n\t Window is shown...");
		// assertFalse(window.frame.isShowing());
		Thread.sleep(1000);

		System.out.println("Running TC1.....");
		Thread.sleep(1000);
		window.ok.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("Empty String Not Permitted");

	
		System.out.println("Now Running TC2....");
		Thread.sleep(1000);
		window.t2.setText("admin123");
		Thread.sleep(1000);
		window.ok.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("Username Required");

		
		System.out.println("Now Running TC3....");
		window.t2.setText("");
		Thread.sleep(1000);		
		window.t1.setText("admin");
		Thread.sleep(1000);
		window.ok.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("Password Required");

		
		System.out.println("Now Running TC4....");
		window.t1.setText("");
		Thread.sleep(1000);
		window.t1.setText("admin");
		window.t2.setText("admin13");
		Thread.sleep(1000);
		window.ok.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("wrong Username or password Required");

		System.out.println("Now Running TC5");
		Thread.sleep(1000);
		window.t1.setText("avanti");
		window.t2.setText("avanti24");
		Thread.sleep(1000);
		window.ok.doClick();
		System.out.println("User Login Successfull");
		//DeleteUserForm.btnLogin.doClick();
		Thread.sleep(1000);
	}
	

	
	@After
	@Override
	protected void tearDown() throws Exception {
		/*String s[] = {};
		AdminSection.main(s);
		AdminSection frame=new AdminSection();
		frame.setVisible(true);
		assertTrue(frame.isShowing());
		Thread.sleep(1000);
		window.dispose();
		super.tearDown();
	*/}


}

	
	
	


