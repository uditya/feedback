import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestLoginPage extends TestCase {
	LoginPage window;
	@Before
	@Override
	protected void setUp() throws Exception {
		window=new LoginPage();
		window.jf.setVisible(true);
		super.setUp();
		System.out.println("\n\t Window Created...");
	}

	@Test
	public void testIsShowing() throws InterruptedException
	{
		assertTrue(window.jf.isShowing());
		System.out.println("\n\t Window is shown...");
		// assertFalse(window.frame.isShowing());
		Thread.sleep(1000);

		System.out.println("Running TC1.....");
		Thread.sleep(1000);
		LoginPage.login.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("Empty String Not Permitted");

	
		System.out.println("Now Running TC2....");
		Thread.sleep(1000);
		LoginPage.passwordfield.setText("admin123");
		Thread.sleep(1000);
		LoginPage.login.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("Username Required");

		
		System.out.println("Now Running TC3....");
		LoginPage.passwordfield.setText("");
		Thread.sleep(1000);		
		LoginPage.usertextfield.setText("admin");
		Thread.sleep(1000);
		LoginPage.login.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("Password Required");

		
		System.out.println("Now Running TC4....");
		LoginPage.usertextfield.setText("");
		Thread.sleep(1000);
		LoginPage.usertextfield.setText("admin");
		LoginPage.passwordfield.setText("admin13");
		Thread.sleep(1000);
		LoginPage.login.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("wrong Username or password Required");

		System.out.println("Now Running TC5");
		Thread.sleep(1000);
		LoginPage.usertextfield.setText("admin");
		LoginPage.passwordfield.setText("admin123");
		Thread.sleep(1000);
		LoginPage.login.doClick();
		System.out.println("Admin Login Successfull");

		System.out.println("Now Running TC6");
		Thread.sleep(1000);
		LoginPage.usertextfield.setText("nirmal");
		LoginPage.passwordfield.setText("nirmal9");
		Thread.sleep(1000);
		LoginPage.login.doClick();
		System.out.println("User Login Successfull");

		
		//LoginPage.btnLogin.doClick();
		Thread.sleep(1000);
	}
	

	
	@After
	@Override
	protected void tearDown() throws Exception {
		/*String s[] = {};
		AdminSection.main(s);
		AdminSection frame=new AdminSection();
		frame.setVisible(true);
		assertTrue(frame.isShowing());
		Thread.sleep(1000);
		window.dispose();
		super.tearDown();
	*/}


}

	
	
	


