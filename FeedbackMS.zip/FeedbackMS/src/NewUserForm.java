import javax.swing.*;

import java.awt.event.*;
import java.awt.*;
import java.util.*;

import javax.swing.JFrame.*;
import javax.swing.JPanel.*;
import javax.swing.JButton.*;
import javax.swing.JLabel.*;
import javax.swing.JPanel.*;
import javax.swing.JRadioButton.*;
import javax.swing.JTextField.*;
import javax.swing.JOptionPane;
import javax.swing.JComboBox.*;

import java.sql.*;
import java.io.*;
public class NewUserForm implements ActionListener
{

public JLabel firstname,lastname,middlename,roll_no,prn,password,year_class,mobno;
public static JButton store;
public static JTextField enterfirstname,entersurname,entermiddlename,enterrollno,enterprn,entermobno;
public static JPasswordField enterpassword;
public JComboBox c_year_class;
public String pass,rno,mno,fname,lname,mname,yclass,prnno,yclass1,getsurname,
	getfirstname,getmiddlename,getrollno,getpassword,getprnno,getmobno;
public JFrame newuserframe;
public JPanel panel3;
public int index,flag;
public Statement st; 
public  ResultSet rs;
public boolean isAlpha(String name) {
    return name.matches("[a-zA-Z]+");
}
public boolean isNumber(String name) {
    return name.matches("[0-9]+");
}
public boolean isAlphaNumeric(String name) {
    return name.matches("[0-9]+[a-zA-Z]");
}

public NewUserForm()
{
	    newuserframe=new JFrame("NewUser Form");
		panel3=new JPanel();
		newuserframe.add(panel3);
		panel3.setBackground(new Color(255,153,255));
		panel3.setLayout(null);
		
		JLabel title=new JLabel("New User Form");
		title.setFont(new Font("Dialog", Font.BOLD, 40));
		title.setBounds(310,70,500,50);
		panel3.add(title);

		
		lastname=new JLabel("Last Name");
		lastname.setBounds(300,200,100,30);
		panel3.add(lastname);
		
		entersurname=new JTextField();
		entersurname.setBounds(500,200,100,30);
		panel3.add(entersurname);
		entersurname.addActionListener(new java.awt.event.ActionListener()
		{
		    public void actionPerformed(java.awt.event.ActionEvent e) {
		        if (!isAlpha(entersurname.getText()))
		        	JOptionPane.showMessageDialog(null,"Invalid...It Contains Numbers or special characters....Reenter please");
		            entersurname.setText("");
		    		}
		});
	


		
		firstname=new JLabel("First Name");
		firstname.setBounds(300,240,100,30);
		panel3.add(firstname);
		
		enterfirstname=new JTextField();
		enterfirstname.setBounds(500,240,100,30);
		panel3.add(enterfirstname);
		enterfirstname.addActionListener(new java.awt.event.ActionListener()
		{
		    public void actionPerformed(java.awt.event.ActionEvent e) {

		        if (!isAlpha(enterfirstname.getText())){
		        	JOptionPane.showMessageDialog(null,"Invalid...It Contains Numbers or special characters....Reenter Please");
		        	enterfirstname.setText("");
		        }
		}});

	
		middlename=new JLabel("Middle Name");
		middlename.setBounds(300,280,100,30);
		panel3.add(middlename);
		
		entermiddlename=new JTextField();
		entermiddlename.setBounds(500,280,100,30);
		panel3.add(entermiddlename);
		entermiddlename.addActionListener(new java.awt.event.ActionListener()
		{
		    public void actionPerformed(java.awt.event.ActionEvent e) {

		        if (!isAlpha(entermiddlename.getText())){
		        	JOptionPane.showMessageDialog(null,"Invalid...It Contains Numbers or special characters....Reeneter Please");
		        	entermiddlename.setText("");
		        }}});
	
		roll_no=new JLabel("Roll no");
		roll_no.setBounds(300,320,100,30);
		panel3.add(roll_no);
		
		enterrollno=new JTextField();
		enterrollno.setBounds(500,320,100,30);
		panel3.add(enterrollno);
		enterrollno.addActionListener(new java.awt.event.ActionListener()
		{
			public void actionPerformed(java.awt.event.ActionEvent e) {
				if (!isNumber(enterrollno.getText())){
                   	JOptionPane.showMessageDialog(null,"It Contains Alphabets or Special Suymbols..Reenter please");
                   	enterrollno.setText("");
				}
		}});
		
		
		year_class=new JLabel("Course and Code");
		year_class.setBounds(300,360,100,30);
		
		panel3.add(year_class);
		
		
		c_year_class=new JComboBox();
		c_year_class.addItem("COMP 1");
		c_year_class.addItem("COMP 2");
		c_year_class.addItem("IT");
		c_year_class.addItem("ELECT");
		c_year_class.addItem("E&TC");
		c_year_class.addItem("MECH");
		c_year_class.setBounds(500,360,100,30);
		panel3.add(c_year_class);
		
		mobno=new JLabel("Mobile No.");
		mobno.setBounds(300,400,100,30);
		panel3.add(mobno);
	
		entermobno=new JTextField();
		entermobno.setBounds(500,400,100,30);
		panel3.add(entermobno);
		entermobno.addActionListener(new java.awt.event.ActionListener()
		{
		    public void actionPerformed(java.awt.event.ActionEvent e) {

		        if (!isAlpha(entermobno.getText())){
		            JOptionPane.showMessageDialog(null,
		                    "It Contains Alphabets or Special Symbols.....Reenter plz");
		            entermobno.setText("");
		        }     
		        if(entermobno.getText().length()!=10)
		        {
		        	JOptionPane.showMessageDialog(null,
		                    "Please Enter 10 digit Number...");
		            entermobno.setText("");
		        
		        }	        
		}});
	
		prn=new JLabel("PRN Number");
		prn.setBounds(300,440,150,30);
		panel3.add(prn);
		
		enterprn=new JTextField();
		enterprn.setBounds(500,440,100,30);
		panel3.add(enterprn);
		enterprn.addActionListener(new java.awt.event.ActionListener()
		{
		    public void actionPerformed(java.awt.event.ActionEvent e) {
		        if (!isAlphaNumeric(enterprn.getText())){
		        	JOptionPane.showMessageDialog(null,"PRN must Start with numbers and end with letters...Reenter please");
		        	enterprn.setText("");
		        }	
		}});
		
		password=new JLabel("Password");
		password.setBounds(300,480,100,30);
		panel3.add(password);
		
		enterpassword=new JPasswordField();
		enterpassword.setBounds(500,480,100,30);
		panel3.add(enterpassword);
	
		
		
		store=new JButton("Submit");
		store.setBounds(400,550,80,30);
		panel3.add(store);
		
	
		store.addActionListener(this);
		GraphicsDevice gd=GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
		int x=gd.getDisplayMode().getWidth();
		int y=gd.getDisplayMode().getHeight();

		newuserframe.setSize(x,y);

		newuserframe.show();

		

	}
	public void storedata()	
	{
			JOptionPane.showMessageDialog(null,"Data Storage Function...");
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/feedbackdb","root","aryan99");
				st = con.createStatement();
		
	        	JOptionPane.showMessageDialog(null,"DB connected");
				System.out.println("third connection established");
				lname=getsurname.toUpperCase();
				fname=enterfirstname.getText().toUpperCase();
				mname=entermiddlename.getText().toUpperCase();
				JOptionPane.showMessageDialog(null,"Surname is "+lname);
				rno=enterrollno.getText();
				Object selectedStateobj = c_year_class.getSelectedItem();
				yclass1 = String.valueOf(selectedStateobj).toUpperCase();
				index = c_year_class.getSelectedIndex();
				yclass=yclass1;
				
				mno=entermobno.getText();
				prnno=enterprn.getText().toUpperCase();
				pass=enterpassword.getText().toUpperCase();
			
				String sql="INSERT INTO tblStudInfo (prn,lastname,firstname,middlename,rollno,coursecode,mobno,password) " +" Values ('"+prnno+"','"+lname+"','"+fname+"','"+mname+"',"+Integer.parseInt(rno)+",'"+yclass+"','"+mno+"','"+pass+"')";
				String feedbacksql="INSERT INTO tblfeedback (prnno,fascilty,environment,teaching,curricular,cleaning,water,complaints,wifi,lab,placement,suggestion) " +" Values ('"+prnno+"','"+"','"+"','"+"','"+"','"+"','"+"','"+"','"+"','"+"','"+"','"+"')";
				//insert into customer (cid,name,age,address,sal) values(1,'Niraj',21,'Pune',45000);
	            Statement st = con.createStatement();
	            st.execute(sql);
	            st.execute(feedbacksql);

				System.out.println("third");	
				st.close();
				con.close();
			
		}	
		catch(Exception ee)
		{
				System.out.println(ee+"exception while putting user data into database");
		}	
	
	
	}

public void actionPerformed(ActionEvent ae)
{
		String s=ae.getActionCommand();
		
		if(s=="Submit")
		{
			getsurname= entersurname.getText();
			getfirstname= enterfirstname.getText();
			getmiddlename= entermiddlename.getText();
			getrollno= enterrollno.getText();
			getmobno= entermobno.getText();
			getprnno= enterprn.getText();
			getpassword= enterpassword.getText();
			if((getsurname.isEmpty()) || (getfirstname.isEmpty())||
					(getmiddlename.isEmpty()) || (getrollno.isEmpty())||
					(getmobno.isEmpty()) || (getprnno.isEmpty())||(getpassword.isEmpty()) )
			{
				System.out.println("Blank String is Not permitted...");
				flag=0;
				JOptionPane.showMessageDialog(null,"Blank String is Not permitted...");
			}
			else
			{

			storedata();
			newuserframe.hide();
			new LoginPage();
			}
			}

}
public static void main(String args[])
{
	new NewUserForm();
	
}

}	