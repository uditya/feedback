import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestAdminPanel extends TestCase {
	AdminPanel window;
	@Before
	@Override
	protected void setUp() throws Exception {
		window=new AdminPanel();
		window.jf4.setVisible(true);
		super.setUp();
		System.out.println("\n\t Window Created...");
	}

	@Test
	public void testIsShowing() throws InterruptedException
	{
		assertTrue(window.jf4.isShowing());
		System.out.println("\n\t Window is shown...");
		// assertFalse(window.frame.isShowing());
		Thread.sleep(1000);

		System.out.println("Running TC1.....");
		Thread.sleep(1000);
		AdminPanel.newuser.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=Pass");
		System.out.println("User Add Window is Opening....");

	
		System.out.println("Now Running TC2....");
		Thread.sleep(1000);
		AdminPanel.delete.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=Pass");
		System.out.println("Panel For Deleting Student Record is Working Fine...");

		
		System.out.println("Now Running TC3....");
		Thread.sleep(1000);		
		AdminPanel.report.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("Password Required");

		
		System.out.println("Now Running TC4....");
		Thread.sleep(1000);
		AdminPanel.cot.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("wrong Username or password Required");

		System.out.println("Now Running TC4");
		Thread.sleep(1000);
		AdminPanel.logout.doClick();
		System.out.println("Window Logout Successfully..");
		//AdminPanel.btnLogin.doClick();
		//Thread.sleep(1000);
	}
	

	
	@After
	@Override
	protected void tearDown() throws Exception {
		/*String s[] = {};
		AdminSection.main(s);
		AdminSection frame=new AdminSection();
		frame.setVisible(true);
		assertTrue(frame.isShowing());
		Thread.sleep(1000);
		window.dispose();
		super.tearDown();
	*/}


}

	
	
	


