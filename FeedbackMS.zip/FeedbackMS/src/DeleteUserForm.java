import javax.swing.*;

import java.awt.event.*;
import java.awt.*;
import java.util.*;
import java.sql.*;
public class DeleteUserForm implements ActionListener
{
Statement stmt;
ResultSet rs;
public String ba,user1,password1;
public JLabel username,password;
public JButton ok;
Connection con;
public JTextField t1,t2;
public JFrame deleteframe;
public JPanel panel6;
public DeleteUserForm()
{
	
	
	deleteframe=new JFrame("Delete User");
	panel6=new JPanel();

	deleteframe.add(panel6);
	//panel6.setBounds(250,20,750,500);
	deleteframe.setBounds(250,20,550,500);
	panel6.setBackground(new Color(255,153,255));
	panel6.setLayout(null);
	//panel6.show();
	
	
	JLabel deltitle=new JLabel("Deleting User");
	deltitle.setBounds(150,50,450,50);
	deltitle.setFont(new Font("Dialog", Font.BOLD, 40));
	panel6.add(deltitle);
	
	username=new JLabel("Enter Username");
	username.setBounds(150,200,150,40);
	panel6.add(username);
	
	password=new JLabel("Enter Password");
	password.setBounds(150,250,150,40);
	panel6.add(password);
	
	
	t1=new JTextField();
	t1.setBounds(270,200,120,30);
	panel6.add(t1);
	
	t2=new JTextField();
	t2.setBounds(270,250,120,30);
	panel6.add(t2);
	
	ok=new JButton("Delete");
	ok.setBounds(210,350,90,30);
	panel6.add(ok);
	
	ok.addActionListener(this);

	deleteframe.show();

}
public void actionPerformed(ActionEvent ae)
{
		String s=ae.getActionCommand();
		
		if(s=="Delete")
		{
			
			try
			{		
				
				user1= t1.getText();
				System.out.println("\n\t username entereed.."+user1);
				password1= new String(t2.getText());
				ba=user1;

				int flag = 1,f;
				if((user1.isEmpty()) && (password1.isEmpty()))
				{
					System.out.println("Blank String is Not permitted...");
					flag++;
					JOptionPane.showMessageDialog(null,"Blank String is Not permitted...");
				}
				else if((user1.isEmpty()) && (password1.length()!=0))
				{
					flag++;
					System.out.println("Username is Required..");
					JOptionPane.showMessageDialog(null,"Username is Required..");
				}
				else if((user1.length()!=0) && (password1.isEmpty()))
				{
					flag++;
					System.out.println("Password is Required...");
					JOptionPane.showMessageDialog(null,"Password is Required...");
				}
				else if(flag!=2)
				{

					Class.forName("com.mysql.jdbc.Driver");
					con=DriverManager.getConnection("jdbc:mysql://localhost:3306/feedbackdb","root","aryan99");
					stmt = con.createStatement();
					
					String sql = "DELETE FROM tblstudInfo WHERE firstname = '"+t1.getText().toUpperCase()+"' AND password='"+t2.getText().toUpperCase()+"'";
					int x=stmt.executeUpdate(sql);
					if(x==1)
					{
		         	JOptionPane.showMessageDialog(null,"User Deleted Successful...");
					}
		         	else
		         	{
						JOptionPane.showMessageDialog(null,"Wrong Username Or Password...");
		         	}
					stmt.close();
					  con.close();
				 	        
			  }	/*
			  else 
			  {
					JOptionPane.showMessageDialog(null,"Wrong Username or Password");
			  }		*/			
				
			}
		 catch(Exception e)
		 {
			System.out.println(e);
				
		 }

				}

}
public static void main(String args[])
{
	new DeleteUserForm();
	
}

}	