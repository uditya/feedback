import javax.swing.*;

import java.awt.event.*;
import java.awt.*;
import java.util.*;

import javax.swing.JFrame.*;
import javax.swing.JPanel.*;
import javax.swing.JButton.*;
import javax.swing.JLabel.*;
import javax.swing.JPanel.*;
import javax.swing.JRadioButton.*;
import javax.swing.JTextField.*;
import javax.swing.JOptionPane;
import javax.swing.JComboBox.*;

import java.sql.*;
public class FeedbackForm extends LoginPage implements ActionListener, ItemListener
{
public static String x,b,c,d,e,f,g,h,i,j,value1,value2,ab,ac;
public Checkbox q1r1,q1r2,q1r3,q2r1,q2r2,q2r3,q3r1,q3r2,q3r3,q4r1,q4r2,q4r3,q5r1,q5r2,q5r3;
public JLabel q1,q2,q3,q4,q5;
public CheckboxGroup bg1,bg2,bg3,bg4,bg5;
public String s_q1,s_q2,s_q3,s_q4,s_q5;


public Checkbox p1r1,p1r2,p1r3,p2r1,p2r2,p2r3,p3r1,p3r2,p3r3,p4r1,p4r2,p4r3,p5r1,p5r2,p5r3;
public JLabel p1,p2,p3,p4,p5;
public CheckboxGroup bx1,bx2,bx3,bx4,bx5;
public String s_p1,s_p2,s_p3,s_p4,s_p5;

public JButton send;
public JLabel label1; 
public JTextArea comment;
public JFrame jf2;
public JPanel panel2;
public Statement st; 
String user1,user2,password1,password2;
public  ResultSet rs;
	public FeedbackForm(String ab)
	{
		ac=ab;
		jf2=new JFrame("second frame");
		panel2=new JPanel();
		jf2.add(panel2);
		panel2.setBackground(new Color(153,153,255));
		panel2.setLayout(null);
		//jf2.setSize(900,900);
	//	jf2.show();
		
		
		JLabel tit=new JLabel("Feedback Form");
		tit.setFont(new Font("Dialog", Font.BOLD, 40));
		tit.setBounds(320,70,400,50);
		panel2.add(tit);
		bg1=new CheckboxGroup();
		bg2=new CheckboxGroup();
		bg3=new CheckboxGroup();
		bg4=new CheckboxGroup();
		bg5=new CheckboxGroup();
	
	
	q1=new JLabel("Q1:  Overall how satisfied are you with facilities provided in Institution ? ");
	q1.setBounds(50,200,500,30);
	panel2.add(q1);
	
	q1r1=new Checkbox("Good",bg1,false);
	q1r1.setBounds(80,240,70,20);
	panel2.add(q1r1);
	q1r1.addItemListener(this);

	q1r2=new Checkbox("Bad",bg1,false);
	q1r2.setBounds(250,240,70,20);
	panel2.add(q1r2);
	q1r2.addItemListener(this);
	
	q1r3=new Checkbox("Average",bg1,false);
	q1r3.setBounds(370,240,100,20);
	panel2.add(q1r3);
	q1r3.addItemListener(this);

	

//second que
q2=new JLabel("Q2:  Overall how satisfied are you with the Environment in College Campus ?");
q2.setBounds(50,270,500,30);
	panel2.add(q2);
	
	
	q2r1=new Checkbox("Good",bg2,false);
	q2r1.setBounds(80,310,70,20);
	panel2.add(q2r1);
q2r1.addItemListener(this);

	q2r2=new Checkbox("Bad",bg2,false);
	q2r2.setBounds(250,310,70,20);
	panel2.add(q2r2);
q2r2.addItemListener(this);
	q2r3=new Checkbox("Average",bg2,false);
	q2r3.setBounds(370,310,100,20);
	panel2.add(q2r3);
q2r3.addItemListener(this);


	
//thired que
q3=new JLabel("Q3:  How satisfied are you with teaching process ?");
	q3.setBounds(50,340,400,30);
	panel2.add(q3);
	
	q3r1=new Checkbox("Good",bg3,false);
	q3r1.setBounds(80,380,70,20);
	panel2.add(q3r1);
q3r1.addItemListener(this);
	
	q3r2=new Checkbox("Bad",bg3,false);
	q3r2.setBounds(250,380,70,20);
	panel2.add(q3r2);
q3r2.addItemListener(this);
	
	q3r3=new Checkbox("Average",bg3,false);
	q3r3.setBounds(370,380,100,20);
	panel2.add(q3r3);
q3r3.addItemListener(this);


//forth que
q4=new JLabel("Q4: How satisfied are you with Curricular and Extra Curricular activities ?");
	q4.setBounds(50,410,500,30);
	panel2.add(q4);
	
	q4r1=new Checkbox("Good",bg4,false);
	q4r1.setBounds(80,450,70,20);
	panel2.add(q4r1);
	q4r1.addItemListener(this);

	q4r2=new Checkbox("Bad",bg4,false);
	q4r2.setBounds(250,450,70,20);
	panel2.add(q4r2);
q4r2.addItemListener(this);
	
	q4r3=new Checkbox("Average",bg4,false);
	q4r3.setBounds(370,450,100,20);
	panel2.add(q4r3);
q4r3.addItemListener(this);

	
//fifth que
q5=new JLabel("Q5: How satisfied are you with Cleanliness in the campus ?");
	q5.setBounds(50,480,400,30);
	panel2.add(q5);
	
	q5r1=new Checkbox("Good",bg5,false);
	q5r1.setBounds(80,520,70,20);
	panel2.add(q5r1);
q5r1.addItemListener(this);

	q5r2=new Checkbox("Bad",bg5,false);
	q5r2.setBounds(250,520,70,20);
	panel2.add(q5r2);
q5r2.addItemListener(this);
	
	q5r3=new Checkbox("Average",bg5,false);
	q5r3.setBounds(370,520,100,20);
	panel2.add(q5r3);
q5r3.addItemListener(this);


	

////////////////2//////////////
		bx1=new CheckboxGroup();
		bx2=new CheckboxGroup();
		bx3=new CheckboxGroup();
		bx4=new CheckboxGroup();
		bx5=new CheckboxGroup();



	p1=new JLabel("Q6: How satisfied are you with Drinking water Facilities ?");
	p1.setBounds(600,200,400,30);
	panel2.add(p1);
	
	p1r1=new Checkbox("Good",bx1,false);
	p1r1.setBounds(630,240,70,20);
	panel2.add(p1r1);
	p1r1.addItemListener(this);

	p1r2=new Checkbox("Bad",bx1,false);
	p1r2.setBounds(750,240,70,20);
	panel2.add(p1r2);
	p1r2.addItemListener(this);
	
	p1r3=new Checkbox("Average",bx1,false);
	p1r3.setBounds(870,240,100,20);
	panel2.add(p1r3);
	p1r3.addItemListener(this);

	

//second que
p2=new JLabel("Q7: How satisfied are you with resolving the complaints ?");
p2.setBounds(600,270,400,30);
	panel2.add(p2);
	
	
	p2r1=new Checkbox("Good",bx2,false);
	p2r1.setBounds(630,310,70,20);
	panel2.add(p2r1);
p2r1.addItemListener(this);

	p2r2=new Checkbox("Bad",bx2,false);
	p2r2.setBounds(750,310,70,20);
	panel2.add(p2r2);
p2r2.addItemListener(this);
	p2r3=new Checkbox("Average",bx2,false);
	p2r3.setBounds(870,310,100,20);
	panel2.add(p2r3);
p2r3.addItemListener(this);


	
//thired que
p3=new JLabel("Q8: You are satisfied with connection spped ? ");
	p3.setBounds(600,340,400,30);
	panel2.add(p3);
	
	p3r1=new Checkbox("Good",bx3,false);
	p3r1.setBounds(630,380,70,20);
	panel2.add(p3r1);
p3r1.addItemListener(this);
	
	p3r2=new Checkbox("Bad",bx3,false);
	p3r2.setBounds(750,380,70,20);
	panel2.add(p3r2);
p3r2.addItemListener(this);
	
	p3r3=new Checkbox("Average",bx3,false);
	p3r3.setBounds(870,380,100,20);
	panel2.add(p3r3);
p3r3.addItemListener(this);


//forth que
p4=new JLabel("Q9: You are satisfied with software available in lab ?");
	p4.setBounds(600,410,400,30);
	panel2.add(p4);
	
	p4r1=new Checkbox("Good",bx4,false);
	p4r1.setBounds(630,450,70,20);
	panel2.add(p4r1);
	p4r1.addItemListener(this);

	p4r2=new Checkbox("Bad",bx4,false);
	p4r2.setBounds(750,450,70,20);
	panel2.add(p4r2);
p4r2.addItemListener(this);
	
	p4r3=new Checkbox("Average",bx4,false);
	p4r3.setBounds(870,450,100,20);
	panel2.add(p4r3);
p4r3.addItemListener(this);

	
//fifth que
p5=new JLabel("Q10: How satisfied are you with Placement provided by us ?");
	p5.setBounds(600,480,400,30);
	panel2.add(p5);
	
	p5r1=new Checkbox("Good",bx5,false);
	p5r1.setBounds(630,520,70,20);
	panel2.add(p5r1);
p5r1.addItemListener(this);

	p5r2=new Checkbox("Bad",bx5,false);
	p5r2.setBounds(750,520,70,20);
	panel2.add(p5r2);
p5r2.addItemListener(this);
	
	p5r3=new Checkbox("Average",bx5,false);
	p5r3.setBounds(870,520,100,20);
	panel2.add(p5r3);
p5r3.addItemListener(this);


	

/////////////////2//////////

		label1=new JLabel("Add Comments and Suggestions");
		
		label1.setBounds(50,560,300,30);
		panel2.add(label1);


		comment=new JTextArea(3,10);
		comment.setBounds(50,600,800,50);
		panel2.add(comment);


		
		send=new JButton("Send");
		send.setBounds(400,660,100,30);
		panel2.add(send);

	
		
		send.addActionListener(this);
	GraphicsDevice gd=GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
int x=gd.getDisplayMode().getWidth();
int y=gd.getDisplayMode().getHeight();

	jf2.setSize(x,y);

		jf2.show();

			
}
public static void main(String args[])
{
	new FeedbackForm("nirmal");
}
public void actionPerformed(ActionEvent ae)
{
	String s=ae.getActionCommand();
		
		
		if(s=="Send")
		{
			allstore();
			jf2.hide();
			new LoginPage();
			
		}
		
}

public void allstore()
{	

	try{

		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db_fms","root","aryan99");

    	Statement stmt = con.createStatement();
	
value1=comment.getText();
System.out.println(value1);
int op = stmt.executeUpdate("update t1_fms set campus='"+x+"',staff='"+b+"' ,canteen='"+c+"',library='"+d+"',bus='"+e+"',p1='"+f+"',p2='"+g+"',p3='"+h+"',p4='"+i+"',p5='"+j+"',comnt='"+value1+"' where firstname='"+ac+"'");	
	
	
	if(op==1)
		{
			System.out.println("Record Saved");
		}
		else
		{
			System.out.println("Record Not Saved");
		}
		stmt.close();
		con.close();
	}
	catch(Exception oo)
	{
		System.out.println(oo);
	}
}
public void itemStateChanged(ItemEvent a)
{
	 x=bg1.getSelectedCheckbox().getLabel();
		b=bg2.getSelectedCheckbox().getLabel();
	//System.out.println("\n\tValue ..."+bg2.getSelectedCheckbox().getLabel());
	 c=bg3.getSelectedCheckbox().getLabel();
		d=bg4.getSelectedCheckbox().getLabel();
		e=bg5.getSelectedCheckbox().getLabel();
		f=bx1.getSelectedCheckbox().getLabel();
		g=bx1.getSelectedCheckbox().getLabel();
		h=bx1.getSelectedCheckbox().getLabel();
		i=bx1.getSelectedCheckbox().getLabel();
		j=bx1.getSelectedCheckbox().getLabel();
		
		
}
}
	

