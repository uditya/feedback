import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestNewUserForm extends TestCase {
	NewUserForm window;
	@Before
	@Override
	protected void setUp() throws Exception {
		window=new NewUserForm();
		window.newuserframe.setVisible(true);
		super.setUp();
		System.out.println("\n\t Window Created...");
	}

	@Test
	public void testIsShowing() throws InterruptedException
	{
		assertTrue(window.newuserframe.isShowing());
		System.out.println("\n\t Window is shown...");
		// assertFalse(winsdow.frame.isShowing());
		Thread.sleep(1000);

		System.out.println("Now Running TC1....");
		Thread.sleep(1000);
		window.entersurname.setText("");
		window.entermiddlename.setText("");
		window.enterfirstname.setText("");
		window.enterrollno.setText("");
		window.entermobno.setText("");
		window.enterprn.setText("");
		window.enterpassword.setText("");
		Thread.sleep(1000);
		window.store.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("Blank Spaces are not Permitted");
			
	
	/*	System.out.println("Now Running TC2....");
		Thread.sleep(1000);
		NewUserForm.entersurname.setText("nirmal123");
		Thread.sleep(1000);
		NewUserForm.store.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=PASS");
		System.out.println("name must be in alphabets...");

		
		System.out.println("Now Running TC3....");
		NewUserForm.enterfirstname.setText("thakare");
		Thread.sleep(1000);
		NewUserForm.store.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("Password Required");

		
		System.out.println("Now Running TC4....");
		Thread.sleep(1000);
		NewUserForm.entermiddlename.setText("admin");
		Thread.sleep(1000);
		NewUserForm.store.doClick();
		Thread.sleep(1000);
		System.out.println("Test Result=FAIL");
		System.out.println("Middle name ");

		System.out.println("Now Running TC5");
		Thread.sleep(1000);
		NewUserForm.enterrollno.setText("268");
		Thread.sleep(1000);
		NewUserForm.store.doClick();
		System.out.println("roll no");

		System.out.println("Now Running TC6");
		Thread.sleep(1000);
		NewUserForm.enterprn.setText("nirmal");
		Thread.sleep(1000);
		NewUserForm.store.doClick();
		System.out.println("User Login Successfull");

		System.out.println("Now Running TC7");
		Thread.sleep(1000);
		NewUserForm.entermobno.setText("nirmal");
		Thread.sleep(1000);
		NewUserForm.store.doClick();
		System.out.println("mob no is invalid");

		
		System.out.println("Now Running TC8");
		Thread.sleep(1000);
		NewUserForm.enterpassword.setText("464574");
		Thread.sleep(1000);
		NewUserForm.store.doClick();
		System.out.println("password is invalid");

		*///NewUserForm.btnLogin.doClick();
		Thread.sleep(1000);
	}
	

	
	@After
	@Override
	protected void tearDown() throws Exception {
		/*String s[] = {};
		AdminSection.main(s);
		AdminSection frame=new AdminSection();
		frame.setVisible(true);
		assertTrue(frame.isShowing());
		Thread.sleep(1000);
		window.dispose();
		super.tearDown();
	*/}


}

	
	
	


